/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.DPE.edu.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;

/**
 *
 * @author labso14
 */
@Entity
@Table(name = "usuarios")
//@NamedQueries({
//    @NamedQuery(name = "Usuarios.findAll", query = "SELECT u FROM Usuarios u")})
public class Usuarios implements Serializable {

    @Column(name = "edad")
    private Integer edad;

    private static final long serialVersionUID = 1L;
    @Id//indica llave primary en la BD
    @GeneratedValue(strategy = GenerationType.IDENTITY)//IDENTITY significa que es autoincrementable
    @Basic(optional = false)
    @Column(name = "codigo" )//nombre del atributo de la tabla
    private Integer codigo;
    @Size(max = 20)
    @Column(name = "nombre_usuario")
    private String nombreUsuario;
    @Size(max = 20)
    @Column(name = "contrase\u00f1a")
    private String contraseña;
    @Size(max = 50)
    @Column(name = "nombre")
    private String nombre;
    @Size(max = 20)
    @Column(name = "sexo")
    private String sexo;
//    @Column(name = "edad")
//    private Integer edad;

    public Usuarios() {
    }

    public Usuarios(Integer codigo) {
        this.codigo = codigo;
    }

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public Integer getEdad() {
        return edad;
    }

    public void setEdad(Integer edad) {
        this.edad = edad;
    }

//    public Integer getEdad() {
//        return edad;
//    }
//
//    public void setEdad(Integer edad) {
//        this.edad = edad;
//    }

   
    
}
